//
//  EventMainVC.swift
//  MidTerm
//
//  Created by Khang Nguyen on 11/6/20.
//

import UIKit
import RealmSwift

class rowInfor: Object {
    @objc dynamic var name: String = ""
    @objc dynamic var guest: String = ""
    @objc dynamic var table: String = ""
    @objc dynamic var section: String = ""
}

class eventInfor: Object {
    @objc dynamic var _eventName: String = ""
    @objc dynamic var _fontSize: Int = 17
    @objc dynamic var _fontStyle: String = ""
    @objc dynamic var _fontColor: String = "Black"
    var guestInfor = List<rowInfor>()
}
protocol AddGuestDelegate: class {
    func didAddGuest(name: String,guest: String, table: String, section: String)
}

class EventMainVC: UIViewController, AddGuestDelegate {
    
    var event = eventInfor()
    
    let realm = try! Realm()
    
    @IBOutlet weak var titleVC: UILabel!
    @IBOutlet weak var listTV: UITableView!
    @IBOutlet weak var eventName: UITextField!
    
    @IBOutlet weak var fontStyle: UILabel!
    @IBOutlet weak var fontSize: UILabel!
    @IBOutlet weak var sizeValue: UISlider!
    @IBOutlet weak var fontColor: UILabel!
    
    @IBAction func takeSize(_ sender: Any) {
        fontSize.text = String(Int(sizeValue.value))
    }
    @IBAction func chooseFontStyle(){
        
    }
    @IBAction func chooseFontColor(){
        
        let alertVC = UIColorPickerViewController()
        
        if let popoverController = alertVC.popoverPresentationController {
                        popoverController.sourceView = self.view //to set the source of your alert
                        popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                        popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                    }
        self.present(alertVC, animated: true, completion: nil)
    }
    @IBAction func clickEdit(){
        listTV.isEditing = !listTV.isEditing
    }
    @IBAction func clickSave(_ sender: Any) {
        //update db
        
        
            try! realm.write{
                event._eventName = eventName.text!
                event._fontSize = Int(sizeValue.value)
                //event._fontStyle = fontStyle.text!
                //event._fontColor = String(fontColor.backgroundColor)
                
            }
    }
    @IBAction func addGuest(){
        
        let dest = storyboard?.instantiateViewController(identifier: "AddGuestVC") as! AddGuestVC
        dest.addGuestDelegate = self
        
        self.navigationController?.pushViewController(dest, animated: true)
    }
    @IBAction func cliclExit(){
        self.navigationController?.popViewController(animated: true)
    }
    func didAddGuest(name: String,guest: String, table: String, section: String)
    {
        let temp = rowInfor()
        temp.name = name
        temp.guest = guest
        temp.table = table
        temp.section = section
        //save data to db
        
        try! realm.write {
            event.guestInfor.append(temp)
        }
        
        listTV.beginUpdates()
        listTV.insertRows(at: [IndexPath(row: event.guestInfor.count-1, section: 0)], with: .automatic)
        listTV.endUpdates()
        
//        print(realm.configuration.fileURL!)
        
    }
    func resetData(){
        try! realm.write {
            realm.deleteAll()
        }
            event = eventInfor()
            try! realm.write{
            realm.add(event)
            }
            sizeValue.value = 17
            listTV.reloadData()
        }
    
    func getDataFromDB() {
        let infor = realm.objects(eventInfor.self)
        if infor.isEmpty
        {
            try! realm.write{
                realm.add(event)
            }
            sizeValue.value = 17
        }
        else{
            sizeValue.value = Float(infor[0]._fontSize)
            eventName.text = infor[0]._eventName
//            event.guestInfor = infor[0].guestInfor
            fontSize.text = String(infor[0]._fontSize)
            //fontStyle.text = infor[0]._fontStyle
            //fontColor.backgroundColor = CGColor(infor?.fontColor)
            event = infor[0]
        }
        
        listTV.reloadData()
        print(realm.configuration.fileURL!)
    }
    override func viewDidLoad() {
        

        // Do any additional setup after loading the view.
        
        listTV.register(guestInfort.self, forCellReuseIdentifier: "guestInfor")
        super.viewDidLoad()
        //getDataFromDB()
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension EventMainVC : UITableViewDataSource, UITableViewDelegate {
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return event.guestInfor.count;
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        let cell: guestInfort = listTV.dequeueReusableCell(withIdentifier: "row", for: indexPath) as! guestInfort
        
        cell.takeData(_name: event.guestInfor[indexPath.row].name, _guest: event.guestInfor[indexPath.row].guest, _table: event.guestInfor[indexPath.row].table, _section: event.guestInfor[indexPath.row].section)
        
        return cell
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    public func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let tempCell = event.guestInfor[sourceIndexPath.row]
        try! realm.write{
        event.guestInfor.remove(at: sourceIndexPath.row)
        event.guestInfor.insert(tempCell,at: destinationIndexPath.row)
        }
        //update db
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            try! realm.write{

                realm.delete(event.guestInfor[indexPath.row])
            }
            tableView.reloadData()
            
            //update db
        }
    }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            if(listTV.cellForRow(at: indexPath)?.isSelected == true)
            {
            let cell: guestInfort = listTV.cellForRow(at: indexPath) as! guestInfort
                cell.name.isEnabled = true
                cell.guest.isEnabled = true
                cell.table.isEnabled = true
                cell.section.isEnabled = true
            }
        }
    func tableView(_ tableView: UITableView, willDeselectRowAt indexPath: IndexPath) -> IndexPath? {
        let cell: guestInfort = listTV.cellForRow(at: indexPath) as! guestInfort
            cell.name.isEnabled = false
            cell.guest.isEnabled = false
            cell.table.isEnabled = false
            cell.section.isEnabled = false
        
        //Bỏ chọn
        tableView.deselectRow(at: indexPath, animated: true)
        
        //update db
        return indexPath
    }
}


