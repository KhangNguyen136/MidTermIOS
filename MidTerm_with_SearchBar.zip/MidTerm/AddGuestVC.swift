//
//  AddGuestVC.swift
//  MidTerm
//
//  Created by Khang Nguyen on 11/6/20.
//

import UIKit

class AddGuestVC: UIViewController {
    weak var addGuestDelegate: AddGuestDelegate? = nil

    @IBOutlet weak var section: UITextField!
    @IBOutlet weak var table: UITextField!
    @IBOutlet weak var numberGuest: UITextField!
    @IBOutlet weak var lName: UITextField!
    @IBOutlet weak var fName: UITextField!
    @IBAction func clickSave(){
        if(fName.text == "" || lName.text == "" || table.text == "" || section.text == "")
        {
            let alertVC = UIAlertController(title: "Message", message: "You have to enter your ìnformation!", preferredStyle: .actionSheet)
            
            let okAction = UIAlertAction(title: "Ok", style: .default)
            alertVC.addAction(okAction)
            if let popoverController = alertVC.popoverPresentationController {
                            popoverController.sourceView = self.view //to set the source of your alert
                            popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                            popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                        }
            self.present(alertVC, animated: true)
            return
            //bug
        }
        if( (Int(numberGuest.text!) == nil))
        {
            let alertVC = UIAlertController(title: "Message", message: "Number of guest must be an integer!", preferredStyle: .actionSheet)
            
            let okAction = UIAlertAction(title: "Ok", style: .default)
            alertVC.addAction(okAction)
            
            if let popoverController = alertVC.popoverPresentationController {
                            popoverController.sourceView = self.view //to set the source of your alert
                            popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                            popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                        }
            self.present(alertVC, animated: true)
            return
            //bug
        }
        let _name = fName.text! + " , " + lName.text!
        let _num = numberGuest.text!
        let _table = table.text!
        let _section = section.text!
        addGuestDelegate?.didAddGuest(name: _name, guest: _num, table: _table, section: _section)
        self.navigationController?.popViewController(animated: true)
        
    }
    @IBAction func clickExit(){
        self.navigationController?.popViewController(animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
