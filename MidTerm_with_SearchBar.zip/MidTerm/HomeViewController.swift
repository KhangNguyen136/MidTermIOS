//
//  ViewController.swift
import UIKit
import RealmSwift

class adminAcc: Object {
    @objc dynamic var username: String = ""
    @objc dynamic var password: String = ""
}
class HomeViewController: UIViewController {
    let realm = try! Realm()
    var admin = adminAcc()
    @IBAction func resetAllDate() {
        let alertVC = UIAlertController(title: "Warning!", message: "All data will be deleted!!!", preferredStyle: .actionSheet)
        
        let okAction = UIAlertAction(title: "Ok", style: .default)
        {_ in
            try! self.realm.write{
                self.realm.deleteAll()
            }
        }
        alertVC.addAction(okAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        alertVC.addAction(cancelAction)
        if let popoverController = alertVC.popoverPresentationController {
                        popoverController.sourceView = self.view //to set the source of your alert
                        popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                        popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                    }
        self.present(alertVC, animated: true)

    }
    func checkInfor() {
        let alert = UIAlertController(title: "Login", message: "Enter your admin account's information", preferredStyle: UIAlertController.Style.alert )
            //Step : 2
            let login = UIAlertAction(title: "Login", style: .default) { (alertAction) in
                let textField = alert.textFields![0] as UITextField
                let textField2 = alert.textFields![1] as UITextField
                
                    if (textField.text == self.admin.username) && (textField2.text == self.admin.password) {
                        let dest = self.storyboard?.instantiateViewController(identifier: "HomeAdminVC") as! HomeAdminVC

                        self.navigationController?.pushViewController(dest, animated: true)
                    }
                    
                 else {
                    let alertVC = UIAlertController(title: "Login false", message: "Username or password ís wrong!", preferredStyle: .actionSheet)
                    
                    let okAction = UIAlertAction(title: "Ok", style: .default)
                    alertVC.addAction(okAction)
                    if let popoverController = alertVC.popoverPresentationController {
                                    popoverController.sourceView = self.view //to set the source of your alert
                                    popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                                    popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                                }
                    self.present(alertVC, animated: true)
                    
                }
            }

            //Step : 3
            //For first TF
            alert.addTextField { (textField) in
                textField.placeholder = "Enter your username!"
                textField.textColor = .red
            }
            //For second TF
            alert.addTextField { (textField) in
                textField.placeholder = "Enter your password!"
                textField.isSecureTextEntry = true
            }

            //Step : 4
            alert.addAction(login)
            //Cancel action
            let cancel = UIAlertAction(title: "Cancel", style: .default) { (alertAction) in
            }
            alert.addAction(cancel)
            //OR single line action
            //alert.addAction(UIAlertAction(title: "Cancel", style: .default) { (alertAction) in })
        if let popoverController = alert.popoverPresentationController {
                        popoverController.sourceView = self.view //to set the source of your alert
                        popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                        popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                    }
            self.present(alert, animated:true, completion: nil)
//        return false
    }
    func registerAdmin()   {
        let alert = UIAlertController(title: "Create admin account", message: "Enter your admin account's information", preferredStyle: UIAlertController.Style.alert )
            //Step : 2
            let save = UIAlertAction(title: "Save", style: .default) { (alertAction) in
                let textField = alert.textFields![0] as UITextField
                let textField2 = alert.textFields![1] as UITextField
                if (textField.text != "") && (textField2.text != "")
                {
                    let temp = adminAcc()
                    temp.username = textField.text!
                    temp.password = textField2.text!
                    try! self.realm.write{
                        self.realm.add(temp)
                    }
                    let dest = self.storyboard?.instantiateViewController(identifier: "HomeAdminVC") as! HomeAdminVC

                    self.navigationController?.pushViewController(dest, animated: true)
                } else {
                    let alertVC = UIAlertController(title: "Message", message: "You have to enter username and password!", preferredStyle: .actionSheet)
                    
                    let okAction = UIAlertAction(title: "Ok", style: .default)
                    alertVC.addAction(okAction)
                    if let popoverController = alertVC.popoverPresentationController {
                                    popoverController.sourceView = self.view //to set the source of your alert
                                    popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                                    popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                                }
                    self.present(alertVC, animated: true)
                    
                }
            }

            //Step : 3
            //For first TF
            alert.addTextField { (textField) in
                textField.placeholder = "Enter your username!"
                textField.textColor = .red
            }
            //For second TF
            alert.addTextField { (textField) in
                textField.placeholder = "Enter your password!"
                textField.isSecureTextEntry = true
            }

            //Step : 4
            alert.addAction(save)
            //Cancel action
            let cancel = UIAlertAction(title: "Cancel", style: .default) { (alertAction) in }
            alert.addAction(cancel)
            //OR single line action
            //alert.addAction(UIAlertAction(title: "Cancel", style: .default) { (alertAction) in })
        if let popoverController = alert.popoverPresentationController {
                        popoverController.sourceView = self.view //to set the source of your alert
                        popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) // you can set this as per your requirement.
                        popoverController.permittedArrowDirections = [] //to hide the arrow of any particular direction
                    }
            self.present(alert, animated:true, completion: nil)

        }
    @IBAction func toAdmin(){
        
        let infor = realm.objects(adminAcc.self)
        if(infor.isEmpty){
            registerAdmin()
        }
        else{
            admin = infor[0]
            checkInfor()
        }
        
        
    }
    @IBAction func toGuest(){
        let dest = self.storyboard?.instantiateViewController(identifier: "GuestHomeVC") as! GuestHomeVC
        self.navigationController?.pushViewController(dest, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


}

